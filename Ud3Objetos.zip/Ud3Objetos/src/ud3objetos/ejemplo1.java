/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ud3objetos;

/**
 *
 * @author 05_1DAW_Alum
 */
public class ejemplo1 {
    public static void main(String[] args) {
        int a, b, c;
        double d;
        
        a = 1;
        b = a++;
        c=++a;
        
        System.out.println("a = " + a + ", b = " + b + ", c = " + c);
        
        d = 1.0/10 + 2.0/10;
        System.out.println(" El resultado es:  " + d * 10);
        
        
    
    
    }
    
}
