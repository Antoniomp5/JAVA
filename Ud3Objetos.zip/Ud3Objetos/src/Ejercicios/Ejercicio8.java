/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

/**
 *
 * @author 05_1DAW_Alum
 */
public class Ejercicio8 {
    public static void main(String[] args) {
        boolean y1 = 3<=5 && 2==2;
        boolean y2 = 3<=5 && 2>10;
        boolean o1 = 1!=2 || 5<3;
        boolean o2 = !(1<2);
        
        System.out.println("Resultado 1: " + y1);    
        System.out.println("Resultado 2: " + y2);  
        System.out.println("Resultado 3: " + o1);  
        System.out.println("Resultado 4: " + o2);  
     }
    
}
