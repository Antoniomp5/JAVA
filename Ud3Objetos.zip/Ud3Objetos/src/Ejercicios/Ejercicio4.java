/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

/**
 *
 * @author 05_1DAW_Alum
 */
public class Ejercicio4 {
    public static void main(String[] args) {
        
    }
    
}
